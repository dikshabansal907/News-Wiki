import React, { Component } from 'react';

export default class NewsItem extends Component {
  render() {
    let{title, description, imageUrl,newsUrl}=this.props;
    const gridContainer={
      display:"inline-grid",
     // gridTemplateRows:"1fr",
      gridTemplateColumns:"1fr 1fr 1fr",
    }
    const gridItem={
      width:"300px"
    }
    const width="300px"
    return(
      <div className='grids'>
        <div style={gridContainer}>
         <div style={gridItem}>
          <img src={imageUrl} alt="#" width={width}/>
          <h1>{title}</h1>
          <p>{description}</p>
          <button><a href={newsUrl} >Read More</a></button>
         </div>
        </div>
      </div>
    )
  }
  // YAHAAAN PE COLUMS KO EXPORT KRAAAA....SMJHI?
}
