import React, { Component } from 'react';
import '../App.css';
// import styles from'./myStyles.css';
export default class Navbar extends Component { 
  render() {
    const myStyle={
        backgroundColor:"black",
        listStyle:"none",
        color:"white",
        height:"7vh",
    }
    const listStyle={
        display:"inline-block",
        padding:"10px",
    }
    return(
    <>
    <div style={myStyle} >
        <ul>
            <li style={listStyle}>News Wiki</li>
            <li style={listStyle}>Home</li>
            <li style={listStyle}>About</li>
        </ul>

    </div>
        
    </>
    )
  }
}
