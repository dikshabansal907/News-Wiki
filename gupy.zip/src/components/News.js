import React, { Component } from 'react';
import NewsItem from './NewsItem';
export default class News extends Component {
    articles=[{
        "source": {
            "id": null,
            "name": "India.com"
        },
        "author": null,
        "title": "Oppo Reno 7 5G with MediaTek Dimensity 900 SoC launched in India: Price, features, pics - Zee News",
        "description": "Oppo has launched the Oppo Reno 7 5G in India. However, the Indian variant is slightly different from the model that was unveiled in China.",
        "url": "https://zeenews.india.com/photos/business/oppo-reno-7-5g-with-mediatek-dimensity-900-soc-launched-in-india-price-features-pics-2433644",
        "urlToImage": "https://english.cdn.zeenews.com/sites/default/files/2022/02/05/1011844-untitled-design-5.jpg",
        "publishedAt": "2022-02-05T06:29:40Z",
        "content": "Oppo Reno 7 5G is powered by the octa-core MediaTek Dimensity 900 SoC coupled with 8GB of RAM and 256GB of onboard storage. The smartphone offers connectivity features such as Wi-Fi 6, Bluetooth v5.2… [+87 chars]"
    },
    {
        "source": {
            "id": null,
            "name": "NDTV News"
        },
        "author": null,
        "title": "India's Positivity Rate Drops To 7.9%, 1,27,952 New Cases, 1,051 Deaths - NDTV",
        "description": "India reported 1,27,952 new Covid cases today, 14% lower than yesterday. The positivity rate fell to 7.9%.The active cases constitute 3.16 per cent of the total infections, while the national COVID-19 recovery rate decreased to 95.64 per cent.",
        "url": "https://www.ndtv.com/india-news/india-covid-positivity-rate-drops-from-9-2-to-7-9-1-27-952-new-cases-14-fewer-than-yesterday-2750368",
        "urlToImage": "https://c.ndtvimg.com/2022-02/v1liuod8_coronavirus-testing-india-afp_650x400_04_February_22.jpg",
        "publishedAt": "2022-02-05T05:34:00Z",
        "content": "<li>Since December, the number of Covid cases has been rising rapidly due to the new variant Omicron. India's active caseload currently stands at 13,31,648.\r\n</li><li>There were 1,059 new Covid-relat… [+1703 chars]"
    },
    {
        "source": {
            "id": null,
            "name": "NDTV News"
        },
        "author": "Edited by Gadgets 360 with inputs from Reuters",
        "title": "iPhone SE 3, New iPad Said to Launch During Apple Event in March - Gadgets 360",
        "description": "Apple plans to launch iPhone SE 3 with 5G capabilities and a new iPad at an event on or near March 8, Bloomberg has reported citing people familiar with the matter.",
        "url": "https://gadgets.ndtv.com/mobiles/news/iphone-se-3-ipad-launch-date-march-8-apple-event-low-cost-5g-phone-price-usd-300-india-testing-2750432",
        "urlToImage": "https://i.gadgets360cdn.com/large/iphone_se_2020_apple_website_1638348112552.jpg",
        "publishedAt": "2022-02-05T04:59:56Z",
        "content": "iPhone SE 3, an update to Apple's iPhone SE (2020) featuring 5G capability, is likely to launch on or near March 8 during a new Apple event along with a new iPad, Bloomberg News reported on Friday, c… [+1376 chars]"
    },
    {
        "source": {
            "id": null,
            "name": "News18"
        },
        "author": "Entertainment Bureau",
        "title": "Tejasswi Prakash Blushes While Karan Kundrra Hides Face As Paparazzi Say, 'Scam Kar Diya Aapne' - News18",
        "description": "Tejasswi Prakash and Karan Kundrra have become one of the most in-demand couples in tinsel town.",
        "url": "https://www.news18.com/news/movies/tejasswi-prakash-blushes-while-karan-kundrra-hides-face-as-paparazzi-say-scam-kar-diya-aapne-4736834.html",
        "urlToImage": "https://images.news18.com/ibnlive/uploads/2022/02/tejasswi-prakash-and-karan-kundrra-4-164403629516x9.jpg",
        "publishedAt": "2022-02-05T04:48:00Z",
        "content": "There is no doubt that Tejasswi Prakash and Karan Kundrra are the new power couple in town. But due to Tejasswis work commitments for her upcoming show Naagin 6, the duo is not able to spend quality … [+1810 chars]"
    }]
  constructor(){
    super();
    console.log("i m constructor");
    this.state={
      articles:this.articles,
      loading:false
    }
  }
//   async componentDidMount(){
//     let url = "https://newsapi.org/v2/top-headlines?country=in&apikey=f3b5aec2f01c4658bec823516a45765b";
//     let data = await fetch(url);
//     let parsedData = await data.json()
//     this.setState({articles: parsedData.articles})
//     }
    
  // iss code mein news keliye rows banaaaa
  render(){
    return(
      <>
      <h2>News Wiki-Top Headlines</h2>
      {/* <div className='ehnu grid row banaaa...ehde ch map lgaake columns bulaa dusri file cho..okay?'> */}
      <div>
      {this.state.articles.map((element)=>{
        return <div key={element.url}>
          <NewsItem title={element.title} description={element.description} imageUrl={element.urlToImage} newsUrl={element.url} />
        </div>
      })}
      </div>
      </>
    )
  }
}

